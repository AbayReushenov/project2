# js-project2
Учебный проект для JavaScript
